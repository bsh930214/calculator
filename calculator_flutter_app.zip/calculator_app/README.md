# 계산기 모음 — Flutter 앱

HTML 계산기를 Flutter WebView로 감싼 iOS/Android 앱입니다.

---

## 📁 구조

```
calculator_app/
├── lib/main.dart              # Flutter 앱 + WebView 브릿지
├── assets/calculator.html     # 계산기 HTML (빌드 시 앱에 번들)
├── android/                   # Android 설정
├── ios/                       # iOS 설정
└── pubspec.yaml               # 의존성
```

---

## 🚀 시작하기

### 1. Flutter 설치
https://flutter.dev/docs/get-started/install

### 2. 의존성 설치
```bash
flutter pub get
```

### 3. 실행
```bash
# Android
flutter run -d android

# iOS (Mac 필요)
flutter run -d ios
```

---

## 📦 빌드 (배포용)

### Android APK / AAB
```bash
# Google Play 제출용 AAB
flutter build appbundle --release

# 직접 설치용 APK
flutter build apk --release
```
빌드 결과: `build/app/outputs/bundle/release/app-release.aab`

### iOS IPA
```bash
flutter build ios --release
# Xcode에서 Archive → Distribute App
```

---

## ⚙️ 출시 전 필수 변경사항

### Android
- `android/app/build.gradle`
  - `applicationId "com.yourcompany.calculator_app"` → 실제 패키지명으로 변경
  - `signingConfig signingConfigs.debug` → 실제 keystore로 교체
  ```bash
  keytool -genkey -v -keystore release.keystore -alias calculator -keyalg RSA -keysize 2048 -validity 10000
  ```

### iOS
- Xcode에서 `Runner` → Signing & Capabilities → Team 설정
- Bundle Identifier 변경

### 앱 아이콘
```bash
flutter pub add flutter_launcher_icons
# pubspec.yaml에 아이콘 설정 후:
flutter pub run flutter_launcher_icons
```

### 스플래시 화면
```bash
flutter pub run flutter_native_splash:create
```

---

## 🔧 localStorage 브릿지

HTML의 `localStorage`는 WebView가 종료되면 초기화될 수 있어서,  
Flutter `SharedPreferences`와 양방향 브릿지로 연결됩니다.

- `localStorage.setItem(k, v)` → `SharedPreferences.setString('ls_k', v)`
- 앱 시작 시 저장된 데이터를 HTML 실행 전 복원

즐겨찾기, 사용 기록, 환율 히스토리 등이 앱 재시작 후에도 유지됩니다.

---

## 📋 의존성

| 패키지 | 용도 |
|--------|------|
| `flutter_inappwebview ^6.0.0` | WebView (iOS WKWebView / Android WebView) |
| `shared_preferences ^2.2.0` | localStorage 영속화 |
| `flutter_native_splash ^2.3.0` | 네이티브 스플래시 |
