import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF0e0f13),
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '계산기 모음',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6c6fff),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF0e0f13),
        useMaterial3: true,
      ),
      home: const WebViewScreen(),
    );
  }
}

class WebViewScreen extends StatefulWidget {
  const WebViewScreen({super.key});

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  InAppWebViewController? _controller;
  bool _isLoading = true;

  // ← 배포 URL
  static const String _url = 'https://calculator-virid-ten-64.vercel.app/';

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (_) async {
        final canGoBack = await _controller?.canGoBack() ?? false;
        if (!canGoBack && mounted) SystemNavigator.pop();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF0e0f13),
        body: SafeArea(
          bottom: false,
          child: Stack(
            children: [
              // ── WebView ──
              InAppWebView(
                initialUrlRequest: URLRequest(url: WebUri(_url)),
                initialSettings: InAppWebViewSettings(
                  javaScriptEnabled: true,
                  domStorageEnabled: true,       // localStorage 유지
                  transparentBackground: true,
                  disableContextMenu: true,
                  supportZoom: false,
                  builtInZoomControls: false,
                  displayZoomControls: false,
                  verticalScrollBarEnabled: false,
                  horizontalScrollBarEnabled: false,
                  overScrollMode: OverScrollMode.NEVER,
                  cacheMode: CacheMode.LOAD_DEFAULT,
                  // 오프라인 대비: 캐시 우선 사용
                  cacheEnabled: true,
                ),
                onWebViewCreated: (controller) {
                  _controller = controller;
                },
                onLoadStop: (controller, _) {
                  if (mounted) setState(() => _isLoading = false);
                },
                onReceivedError: (controller, request, error) {
                  // 오프라인 등 오류 시 캐시로 재시도
                  controller.loadUrl(
                    urlRequest: URLRequest(
                      url: WebUri(_url),
                      cachePolicy: URLRequestCachePolicy.RETURN_CACHE_DATA_ELSE_LOAD,
                    ),
                  );
                },
              ),

              // ── 로딩 스플래시 ──
              AnimatedOpacity(
                opacity: _isLoading ? 1.0 : 0.0,
                duration: const Duration(milliseconds: 350),
                child: IgnorePointer(
                  ignoring: !_isLoading,
                  child: Container(
                    color: const Color(0xFF0e0f13),
                    child: const Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('🧮', style: TextStyle(fontSize: 56)),
                          SizedBox(height: 16),
                          Text(
                            '계산기 모음',
                            style: TextStyle(
                              color: Color(0xFF6c6fff),
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              decoration: TextDecoration.none,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            '잠깐만요...',
                            style: TextStyle(
                              color: Color(0xFF5a5f72),
                              fontSize: 14,
                              decoration: TextDecoration.none,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
